import info from "./mock/myInfo.js"
export default {
  data: {
    o3DwxGNKQR:JSON.stringify(info)
  },
  prerenderedAt: 1676365656385,
};
