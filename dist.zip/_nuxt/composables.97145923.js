import{k as r}from"./entry.7332453d.js";function t(e,u){return r()._useHead(e,u)}export{t as u};
